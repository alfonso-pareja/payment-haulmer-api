<?php

return [
    App\Providers\RepositoryServiceProvider::class,
];
